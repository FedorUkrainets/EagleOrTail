let phrases = ['Орёл', 'Решка' ]

function getRandomIndex(arr) {
    let randIndex = Math.floor(Math.random() * arr.length);
    return arr[randIndex];
}

let result = document.querySelector('.result');
let button = document.querySelector('.button');

button.addEventListener('click', function() {
    let randomElement = getRandomIndex(phrases)
    result.textContent = randomElement;
})

